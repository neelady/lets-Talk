<?php
  $hostname = "localhost";
  $username = "root";
  $password = "";
  $dbname = "lets_talk";

  $conn = mysqli_connect($hostname, $username, $password, $dbname);
  if(!$conn){
    echo "Database connection error".mysqli_connect_error();
  }

  function fetch_user_chat_history($incoming_msg_id, $outgoing_msg_id, $conn)
  {
   $query = "
   SELECT * FROM msg_group 
   WHERE (incoming_msg_id = '".$incoming_msg_id."' 
   AND outgoing_msg_id= '".$outgoing_msg_id."') 
   OR (incoming_msg_id = '".$outgoing_msg_id."' 
   AND outgoing_msg_id= '".$incoming_msg_id."') 
   ORDER BY timestamp DESC
   ";
   $statement = $conn->prepare($query);
   $statement->execute();
   $result = $statement->fetchAll();
   $output = '<ul class="list-unstyled">';
   foreach($result as $row)
   {
    $user_name = '';
    if($row["incoming_msg_id"] == $incoming_msg_id)
    {
     $user_name = '<b class="text-success">You</b>';
    }
    else
    {
     $user_name = '<b class="text-danger">'.get_user_name($row['incoming_msg_id'], $conn).'</b>';
    }
    $output .= '
    <li style="border-bottom:1px dotted #ccc">
     <p>'.$user_name.' - '.$row["chat"].'
      <div align="right">
       - <small><em>'.$row['timestamp'].'</em></small>
      </div>
     </p>
    </li>
    ';
   }
   $output .= '</ul>';
   return $output;
  }
  
  function get_user_name($user_id, $conn)
  {
   $query = "SELECT fname FROM users WHERE user_id = '$user_id'";
   $statement = $connect->prepare($query);
   $statement->execute();
   $result = $statement->fetchAll();
   foreach($result as $row)
   {
    return $row['fname'];
   }
  }
  














?>
