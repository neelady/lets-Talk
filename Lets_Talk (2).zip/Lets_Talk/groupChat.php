<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  } 
?>
<?php include_once "header.php"; ?>
<body>
  <div class="wrapper">
    <section class="chat-area">
      <header>
       
        <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
       
        <div class="details">
            
             <h4>Group Chat</h4>
        </div>
      </header>
      <div class="chat-box">

      </div>
      <form action="#" class="typing-area">
        <input type="text" class="incoming_id" name="incoming_id" value="<?php echo $user_id; ?>" hidden>
        <input type="text" name="message" class="input-field" placeholder="Type a message here..." autocomplete="off">
        <button name="send_chat" id="'+outgoing_msg_id+'"  ><i class="fab fa-telegram-plane"></i></button>
      </form>
    </section>
  </div>

  <script >
  
  
  
  $(document).ready(function(){

       
function make_chat_dialog_box(outgoing_msg_id, incoming_msg_id)
{
 var modal_content = '<div id="user_dialog_'+outgoing_msg_id+'" class="user_dialog" title="You have chat with '+to_user_name+'">';
 modal_content += '<div style="height:400px; border:1px solid #ccc; overflow-y: scroll; margin-bottom:24px; padding:16px;" class="chat_history" data-touserid="'+outgoing_msg_id+'" id="chat_history_'+outgoing_msg_id+'">';
 modal_content += '</div>';
 modal_content += '<div class="form-group">';
 modal_content += '<textarea name="chat_message_'+outgoing_msg_id+'" id="chat_message_'+outgoing_msg_id+'" class="form-control"></textarea>';
 modal_content += '</div><div class="form-group" align="right">';
 modal_content+= '<button type="button" name="send_chat" id="'+outgoing_msg_id+'" class="btn btn-info send_chat">Send</button></div></div>';
 $('#user_model_details').html(modal_content);
}

$(document).on('click', '.start_chat', function(){
 var outgoing_msg_id = $(this).data('outgoing_msg_id');
 var incoming_msg_id = $(this).data('incoming_msg_id');
 make_chat_dialog_box(outgoing_msg_id, to_user_name);
 $("#user_dialog_"+outgoing_msg_id).dialog({
  autoOpen:false,
  width:400
 });
 $('#user_dialog_'+outgoing_msg_id).dialog('open');
});

});

$(document).on('click', '.send_chat', function(){
var toutgoing_msg_id = $(this).attr('id');
var chat = $('#chat_message_'+outgoing_msg_id).val();
$.ajax({
 url:"insert.php",
 method:"POST",
 data:{outgoing_msg_id:outgoing_msg_id, chat:chat},
 success:function(data)
 {
  $('#chat_message_'+outgoing_msg_id).val('');
  $('#chat_history_'+outgoing_msg_id).html(data);
 }
})
});

function fetch_user_chat_history(outgoing_msg_id)
 {
  $.ajax({
   url:"fetch_user_chat_history.php",
   method:"POST",
   data:{outgoing_msg_id:outgoing_msg_id},
   success:function(data){
    $('#chat_history_'+outgoing_msg_id).html(data);
   }
  })
 }
  
  
  
  
  
  
  
  </script>

</body>
</html>
