<?php

//insert_chat.php
session_start();
include_once "php/config.php";

if(isset($_SESSION['unique_id'])){

$data = array(
 ':outgoing_msg_id'  => $_POST['outgoing_msg_id'],
 ':incoming_msg_id'  => $_SESSION['unique_id'],
 ':chat'  => $_POST['chat']
 
);

$query = "
INSERT INTO msg_group
(outgoing_msg_id, incoming_msg_id, chat) 
VALUES (:to_user_id, :from_user_id, :chat)";

$statement = $connect->prepare($query);

if($statement->execute($data))
{
 echo fetch_user_chat_history($_SESSION['unique_id'], $_POST['outgoing_msg_id'], $connect);
}
}

else{
    header("location: ../login.php");
}


?>
